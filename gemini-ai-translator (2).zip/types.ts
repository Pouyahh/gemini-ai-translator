export interface Language {
  code: string;
  name: string;
  rtl?: boolean;
}